B02 SQL Server 2022 實驗包
先讀線上書籍 labs 與 verification。labs.md 的章節連結需回到線上書籍；本包提供SQL與驗收程式。
verify_docker.py 只接受帶 book=b02 label 的 b02-sql2022 容器與不存在的 B02Lab/B02Concurrent/B02Restored；不刪資料。verify_network.py 需先完成前者，且要求Docker Desktop主機轉接。
用 sqlcmd -b 執行單檔；不要在正式資料庫執行。
