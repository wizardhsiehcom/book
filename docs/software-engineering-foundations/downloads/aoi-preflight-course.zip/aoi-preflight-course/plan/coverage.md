# B01／C00 概念對照

B01 位於相鄰 book repo 的 docs/software-engineering-foundations。下表是本地檔案索引，未發布外部 URL。

| 概念 | B01 原理頁 | C00 程式／活動 | 驗收 |
|---|---|---|---|
| 產物 | 01-build.md | G00 main、G06 多翻譯單元 | 錯誤 fixture、漏連結的解釋 |
| 值／參照／生命週期 | 02-values.md、03-lifetime.md | G01 Row、G02 load | 修改副本與原物件、資源何時釋放 |
| 容器／複雜度 | 04-containers.md、05-complexity.md | G02／G03 load | 身分不變、比較次數與順序 |
| 契約／錯誤 | 06-contracts.md、07-errors.md | G02 number、G04 inspect、G05 main | 壞欄／空檔／邊界 |
| 模組／測試 | 08-modules.md、09-tests.md | G06、tools/check.py | 拆分等價、門檻反例 |
| 除錯／效能 | 10-debugging.md、11-performance.md | G01 breakpoint、G03 分析 | 固定假設與觀察範圍 |
| Git／CI | 12-git.md、13-delivery.md | 每階 diff、workflow | 不混合修改、平台證據 |
| Python 遷移 | 14-python.md | B01 python_bridge.py；course.py 為實際用例 | 共用物件與 subprocess 結果 |

現有 C++／SQL 書的 02-one-job、03-test-mode 已讀，具體的固定入口案例不在 B01 全文重製；此處新增通用原理與獨立小實驗。Siguard 前兩階只提供用途證據，不複製其 parser 或客戶圖片。
