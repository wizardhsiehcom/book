# C00 正式課程計畫

版本 2026-09-26；本輪範圍 G00–G06、B01 配套及一個遷移題。讀者具基礎語法，未能穩定追蹤擁有權、外部輸入與修改邊界。終點是可執行的離線清單與圖片檢查器。

不涵蓋 SQL、GPU、圖像解碼、網路與線上機台；資料是本課自訂，不代表產線格式。全程只讀輸入、報告到 stdout。書課內容與程式均在本輪交付，不將文字無限延後。

## 來源與先備

先讀 [data/README](../data/README.md) 的來源、已讀範圍與限制。G00／G01 解釋基本語法，G02 詳述容器與解析；後段僅補第一次出現的概念。建置工具是配套，不要求初學者先理解 Python 才學 C++。

## 能力階梯

| 階段 | 前置／觸發 | 新能力 | 主要概念 |
|---|---|---|---|
| G00 | 讀者起點；工具鏈或工作目錄設錯 | 00-environment | C++ 標準、有效檢查、工作目錄 |
| G01 | G00；先知道固定三筆哪些待判且缺圖 | 01-fixed | 值／const&／作用域／ifstream |
| G02 | G01；新批次筆數／內容變動 | 02-load | vector、istream、from_chars、契約 |
| G03 | G02；逐筆掃描查重的比較次數增長 | 03-identity | 集合、身分、平均與最壞複雜度 |
| G04 | G03；開啟探測不能區分空檔與目錄 | 04-files | filesystem、error_code、檔案政策 |
| G05 | G04；不同批次最低檔案大小要求不同 | 05-policy | 參數、範圍、帶符號到無號轉換 |
| G06 | G05；入口與規則需要分開閱讀、修改與驗證 | 06-modules | 宣告／定義、翻譯單元、契約回歸 |

## 階段卡

### G00 00-environment

**A 接續與目標。** 環境階段；前置 安裝 compiler/Python。觸發：工具鏈或工作目錄設錯。完成後能預測本階新輸入的行為、指出修改處並核對結果。本階不增加 SQL、網路或解碼。

**B 問題與實驗。** 預測題、情境與允許結果在 [正文](../docs/00-environment.md)；先記答案才執行。核心機制：C++ 標準、有效檢查、工作目錄。反例使用 fixtures 或測試建立的暫存目錄，不改正式資料。

**C 演進。** 完整快照 [main.cpp](../lessons/00-environment/main.cpp)。加入環境報告，實際觸發錯誤以檢查檢查器。G06 同時含 checker.h／checker.cpp，僅分離定義，不改報告契約。新 API 在首次原碼註解說明；沿用概念回查前階。

**D 執行契約。** 課程目錄（`courses/aoi-preflight-course/`）執行 `python3 tools/course.py run 0`。正常 exit 0；錯誤 fixture exit 2。固定合成資料；無背景服務。Ctrl+C 可停止，入口設 30 秒上限。重跑不改來源；例外輸出 ERROR 並回 2。平台以 verification 為準。

**E 學習驗收。** [練習](../exercises/00-environment.md)要求預測、解釋、修改及排錯；[提示](../solutions/00-environment-hints.md)與[解答](../solutions/00-environment.md)分開。不是只跑 selftest：須交 diff、輸入、預測與結果；一週後換值回測。

**F 工程驗收。** `tools/check.py` 對本階跑真 exe，涵蓋正常與適用反例；[驗證紀錄](../verification/results.md)列環境與實測結果。下一階開始產出資料報告。

### G01 01-fixed

**A 接續與目標。** 主線階段；前置 G00 可執行快照。觸發：先知道固定三筆哪些待判且缺圖。完成後能預測本階新輸入的行為、指出修改處並核對結果。本階不增加 SQL、網路或解碼。

**B 問題與實驗。** 預測題、情境與允許結果在 [正文](../docs/01-fixed.md)；先記答案才執行。核心機制：值／const&／作用域／ifstream。反例使用 fixtures 或測試建立的暫存目錄，不改正式資料。

**C 演進。** 完整快照 [main.cpp](../lessons/01-fixed/main.cpp)。保留前版，對照正文「只改這一步」的差異；用 git diff --no-index 比較。G06 同時含 checker.h／checker.cpp，僅分離定義，不改報告契約。新 API 在首次原碼註解說明；沿用概念回查前階。

**D 執行契約。** 課程目錄（`courses/aoi-preflight-course/`）執行 `python3 tools/course.py run 1 -- fixtures/images`。預設資料 exit 1，ready=1、issues=1；G01 total 固定 3，G02 起按資料計數。固定合成資料；無背景服務。Ctrl+C 可停止，入口設 30 秒上限。重跑不改來源；例外輸出 ERROR 並回 2。平台以 verification 為準。

**E 學習驗收。** [練習](../exercises/01-fixed.md)要求預測、解釋、修改及排錯；[提示](../solutions/01-fixed-hints.md)與[解答](../solutions/01-fixed.md)分開。不是只跑 selftest：須交 diff、輸入、預測與結果；一週後換值回測。

**F 工程驗收。** `tools/check.py` 對本階跑真 exe，涵蓋正常與適用反例；[驗證紀錄](../verification/results.md)列環境與實測結果。下一階：新批次筆數／內容變動。

### G02 02-load

**A 接續與目標。** 主線階段；前置 G01 可執行快照。觸發：新批次筆數／內容變動。完成後能預測本階新輸入的行為、指出修改處並核對結果。本階不增加 SQL、網路或解碼。

**B 問題與實驗。** 預測題、情境與允許結果在 [正文](../docs/02-load.md)；先記答案才執行。核心機制：vector、istream、from_chars、契約。反例使用 fixtures 或測試建立的暫存目錄，不改正式資料。

**C 演進。** 完整快照 [main.cpp](../lessons/02-load/main.cpp)。保留前版，對照正文「只改這一步」的差異；用 git diff --no-index 比較。G06 同時含 checker.h／checker.cpp，僅分離定義，不改報告契約。新 API 在首次原碼註解說明；沿用概念回查前階。

**D 執行契約。** 課程目錄（`courses/aoi-preflight-course/`）執行 `python3 tools/course.py run 2 -- fixtures/defects.txt fixtures/images`。預設資料 exit 1，ready=1、issues=1；G01 total 固定 3，G02 起按資料計數。固定合成資料；無背景服務。Ctrl+C 可停止，入口設 30 秒上限。重跑不改來源；例外輸出 ERROR 並回 2。平台以 verification 為準。

**E 學習驗收。** [練習](../exercises/02-load.md)要求預測、解釋、修改及排錯；[提示](../solutions/02-load-hints.md)與[解答](../solutions/02-load.md)分開。不是只跑 selftest：須交 diff、輸入、預測與結果；一週後換值回測。

**F 工程驗收。** `tools/check.py` 對本階跑真 exe，涵蓋正常與適用反例；[驗證紀錄](../verification/results.md)列環境與實測結果。下一階：逐筆掃描查重的比較次數增長。

### G03 03-identity

**A 接續與目標。** 主線階段；前置 G02 可執行快照。觸發：逐筆掃描查重的比較次數增長。完成後能預測本階新輸入的行為、指出修改處並核對結果。本階不增加 SQL、網路或解碼。

**B 問題與實驗。** 預測題、情境與允許結果在 [正文](../docs/03-identity.md)；先記答案才執行。核心機制：集合、身分、平均與最壞複雜度。反例使用 fixtures 或測試建立的暫存目錄，不改正式資料。

**C 演進。** 完整快照 [main.cpp](../lessons/03-identity/main.cpp)。保留前版，對照正文「只改這一步」的差異；用 git diff --no-index 比較。G06 同時含 checker.h／checker.cpp，僅分離定義，不改報告契約。新 API 在首次原碼註解說明；沿用概念回查前階。

**D 執行契約。** 課程目錄（`courses/aoi-preflight-course/`）執行 `python3 tools/course.py run 3 -- fixtures/defects.txt fixtures/images`。預設資料 exit 1，ready=1、issues=1；G01 total 固定 3，G02 起按資料計數。固定合成資料；無背景服務。Ctrl+C 可停止，入口設 30 秒上限。重跑不改來源；例外輸出 ERROR 並回 2。平台以 verification 為準。

**E 學習驗收。** [練習](../exercises/03-identity.md)要求預測、解釋、修改及排錯；[提示](../solutions/03-identity-hints.md)與[解答](../solutions/03-identity.md)分開。不是只跑 selftest：須交 diff、輸入、預測與結果；一週後換值回測。

**F 工程驗收。** `tools/check.py` 對本階跑真 exe，涵蓋正常與適用反例；[驗證紀錄](../verification/results.md)列環境與實測結果。下一階：開啟探測不能區分空檔與目錄。

### G04 04-files

**A 接續與目標。** 主線階段；前置 G03 可執行快照。觸發：開啟探測不能區分空檔與目錄。完成後能預測本階新輸入的行為、指出修改處並核對結果。本階不增加 SQL、網路或解碼。

**B 問題與實驗。** 預測題、情境與允許結果在 [正文](../docs/04-files.md)；先記答案才執行。核心機制：filesystem、error_code、檔案政策。反例使用 fixtures 或測試建立的暫存目錄，不改正式資料。

**C 演進。** 完整快照 [main.cpp](../lessons/04-files/main.cpp)。保留前版，對照正文「只改這一步」的差異；用 git diff --no-index 比較。G06 同時含 checker.h／checker.cpp，僅分離定義，不改報告契約。新 API 在首次原碼註解說明；沿用概念回查前階。

**D 執行契約。** 課程目錄（`courses/aoi-preflight-course/`）執行 `python3 tools/course.py run 4 -- fixtures/defects.txt fixtures/images`。預設資料 exit 1，ready=1、issues=1；G01 total 固定 3，G02 起按資料計數。固定合成資料；無背景服務。Ctrl+C 可停止，入口設 30 秒上限。重跑不改來源；例外輸出 ERROR 並回 2。平台以 verification 為準。

**E 學習驗收。** [練習](../exercises/04-files.md)要求預測、解釋、修改及排錯；[提示](../solutions/04-files-hints.md)與[解答](../solutions/04-files.md)分開。不是只跑 selftest：須交 diff、輸入、預測與結果；一週後換值回測。

**F 工程驗收。** `tools/check.py` 對本階跑真 exe，涵蓋正常與適用反例；[驗證紀錄](../verification/results.md)列環境與實測結果。下一階：不同批次最低檔案大小要求不同。

### G05 05-policy

**A 接續與目標。** 主線階段；前置 G04 可執行快照。觸發：不同批次最低檔案大小要求不同。完成後能預測本階新輸入的行為、指出修改處並核對結果。本階不增加 SQL、網路或解碼。

**B 問題與實驗。** 預測題、情境與允許結果在 [正文](../docs/05-policy.md)；先記答案才執行。核心機制：參數、範圍、帶符號到無號轉換。反例使用 fixtures 或測試建立的暫存目錄，不改正式資料。

**C 演進。** 完整快照 [main.cpp](../lessons/05-policy/main.cpp)。保留前版，對照正文「只改這一步」的差異；用 git diff --no-index 比較。G06 同時含 checker.h／checker.cpp，僅分離定義，不改報告契約。新 API 在首次原碼註解說明；沿用概念回查前階。

**D 執行契約。** 課程目錄（`courses/aoi-preflight-course/`）執行 `python3 tools/course.py run 5 -- fixtures/defects.txt fixtures/images 1`。預設資料 exit 1，ready=1、issues=1；G01 total 固定 3，G02 起按資料計數。固定合成資料；無背景服務。Ctrl+C 可停止，入口設 30 秒上限。重跑不改來源；例外輸出 ERROR 並回 2。平台以 verification 為準。

**E 學習驗收。** [練習](../exercises/05-policy.md)要求預測、解釋、修改及排錯；[提示](../solutions/05-policy-hints.md)與[解答](../solutions/05-policy.md)分開。不是只跑 selftest：須交 diff、輸入、預測與結果；一週後換值回測。

**F 工程驗收。** `tools/check.py` 對本階跑真 exe，涵蓋正常與適用反例；[驗證紀錄](../verification/results.md)列環境與實測結果。下一階：入口與規則需要分開閱讀、修改與驗證。

### G06 06-modules

**A 接續與目標。** 主線階段；前置 G05 可執行快照。觸發：入口與規則需要分開閱讀、修改與驗證。完成後能預測本階新輸入的行為、指出修改處並核對結果。本階不增加 SQL、網路或解碼。

**B 問題與實驗。** 預測題、情境與允許結果在 [正文](../docs/06-modules.md)；先記答案才執行。核心機制：宣告／定義、翻譯單元、契約回歸。反例使用 fixtures 或測試建立的暫存目錄，不改正式資料。

**C 演進。** 完整快照 [main.cpp](../lessons/06-modules/main.cpp)。保留前版，對照正文「只改這一步」的差異；用 git diff --no-index 比較。G06 同時含 checker.h／checker.cpp，僅分離定義，不改報告契約。新 API 在首次原碼註解說明；沿用概念回查前階。

**D 執行契約。** 課程目錄（`courses/aoi-preflight-course/`）執行 `python3 tools/course.py run 6 -- fixtures/defects.txt fixtures/images 1`。預設資料 exit 1，ready=1、issues=1；G01 total 固定 3，G02 起按資料計數。固定合成資料；無背景服務。Ctrl+C 可停止，入口設 30 秒上限。重跑不改來源；例外輸出 ERROR 並回 2。平台以 verification 為準。

**E 學習驗收。** [練習](../exercises/06-modules.md)要求預測、解釋、修改及排錯；[提示](../solutions/06-modules-hints.md)與[解答](../solutions/06-modules.md)分開。不是只跑 selftest：須交 diff、輸入、預測與結果；一週後換值回測。

**F 工程驗收。** `tools/check.py` 對本階跑真 exe，涵蓋正常與適用反例；[驗證紀錄](../verification/results.md)列環境與實測結果。結束於 capstone 遷移；不宣稱產線能力。

## 主線連續性與限制

G01 用固定 Row 與真實檔案探測；G02 改成真外部清單，G03 保留資料與報告順序只改查重；G04 保留同一資料流並深化檔案檢查；G05 引入 minimum；G06 移動函式定義。沒有把前階能力偷換成假函式。

只有 G01 的固定清單是暫時資料替身，G02 即接回檔案。圖片全為合成，但 filesystem 操作是真實的；所有階段都不宣稱圖像解碼。最終同一份清單真正流經解析、選取、檔案檢查到報告。

## 產物與追蹤

正文 docs、快照 lessons、讀者輸入 fixtures、練習 exercises、提示／答案 solutions、備料 data、驗證 verification；概念對照另見 coverage.md。環境檢查原碼純 ASCII，整體 C++17。無 CMake 依賴，避免將建置系統學習提前成為門檻。

| 項目 | 狀態 |
|---|---|
| G00–G06 計畫／正文／程式／練習／解答 | 已建立 |
| 工程驗證 | 以 verification/results.md 為準 |
| 讀者實際驗收 | 尚未執行 |
| Windows／Linux／遠端 CI | 尚未實機驗證 |

## 已定與待確認

- 已定：B01 在 book repo，C00 放在 courses repo 的 aoi-preflight-course/ 子目錄；原理與程式演進分工。
- 已定：macOS Clang 實測，MSVC 只提供操作路徑，未驗證不冒稱支援完成。
- 已定：本地安全工具，拒絕 duplicate／壞欄，缺圖回 1；不直接移植原機台格式。
- 待確認：讀者的實際先備程度與正式資料轉接需求。這些不阻擋合成工具教材，但會影響後續遷移深度。
