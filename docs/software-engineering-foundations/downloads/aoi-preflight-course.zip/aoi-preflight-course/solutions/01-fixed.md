# G01 解答與判準

只改 id=2 時 pending=3、ready=2、issues=1。再加缺圖 id=4 時 total=4、pending=4、ready=2、issues=2。total 不應仍硬寫 3，可加 total 計數並每輪先累加。

合格需指出因果與觀察位置；只貼成功輸出不算解釋。若結果不同，先確認編譯產物、工作目錄與輸入是否和預測一致，不能為了得到答案修改待驗規則。
