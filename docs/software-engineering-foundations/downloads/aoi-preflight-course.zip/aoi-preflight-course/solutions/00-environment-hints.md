# G00 提示

核對參數指到的 fixture，並讀 require 呼叫。

先回去嘗試，再看同目錄的 `00-environment.md` 解答。
