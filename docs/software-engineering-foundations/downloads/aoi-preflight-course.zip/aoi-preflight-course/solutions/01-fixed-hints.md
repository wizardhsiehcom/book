# G01 提示

追蹤哪些計數在 continue 前後；陣列可用 range-for 計總數。

先回去嘗試，再看同目錄的 `01-fixed.md` 解答。
