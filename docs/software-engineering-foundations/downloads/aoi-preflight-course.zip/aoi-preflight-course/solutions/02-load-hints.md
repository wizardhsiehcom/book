# G02 提示

load 完全成功後才 report；judge 決定是否查圖。

先回去嘗試，再看同目錄的 `02-load.md` 解答。
