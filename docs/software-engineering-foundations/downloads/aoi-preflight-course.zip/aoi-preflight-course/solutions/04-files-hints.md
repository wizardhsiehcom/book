# G04 提示

看 inspect 的分支順序與 error_code；不要誤把 file_size 失敗值當大小。

先回去嘗試，再看同目錄的 `04-files.md` 解答。
