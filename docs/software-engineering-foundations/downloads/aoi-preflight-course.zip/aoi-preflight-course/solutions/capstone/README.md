# 遷移題參考解

先讀 exercises/capstone.md，這裡是完整可跑參考，採單檔方便對照，不要求讀者也把 G06 合回單檔。

`report` 接受 all 與 extension，選取時只在 !all 的情況略過已判列；檔名由合法整數與限定的副檔名產生。`main` 拒絕未知 scope／extension；parser 不放寬。selected 表示這次真正檢查的列，避免 all 時仍叫 pending。

在 課程目錄（`courses/aoi-preflight-course/`）、build 已存在時：

```sh
c++ -std=c++17 -O0 -g solutions/capstone/main.cpp -o build/capstone
./build/capstone fixtures/defects.txt fixtures/images 1 all png
```

Windows 由 Native Tools 終端用：

```bat
cl /nologo /std:c++17 /EHsc /utf-8 solutions/capstone/main.cpp /Fe:build/capstone.exe
build\capstone.exe fixtures/defects.txt fixtures/images 1 all png
```

all/png/1：total=3 selected=3 ready=2 issues=1，exit 1。pending/png/1：selected=2 ready=1 issues=1。沒有 jpg 時都應 missing；不能把 png 存在當成 jpg 存在。

這個解法的目的是保存既有契約後增加兩個真需求。不接收任意 suffix 路徑，不把 all 寫成修改每筆 judge=-1，也不因此移除重複 id 檢查。參考解有真執行驗證，見 verification/results.md。
