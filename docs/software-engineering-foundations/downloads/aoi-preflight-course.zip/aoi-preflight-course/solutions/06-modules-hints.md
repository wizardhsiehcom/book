# G06 提示

宣告讓 compiler 知道呼叫形狀，定義要由 linker 找到。

先回去嘗試，再看同目錄的 `06-modules.md` 解答。
