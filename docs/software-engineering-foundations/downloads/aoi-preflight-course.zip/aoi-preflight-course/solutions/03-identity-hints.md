# G03 提示

身分只取 id，不能把 judge 加進查重 key。

先回去嘗試，再看同目錄的 `03-identity.md` 解答。
