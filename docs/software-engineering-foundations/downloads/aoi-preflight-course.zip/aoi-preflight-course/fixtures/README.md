# 合成輸入

`defects.txt` 有三筆：1、3 待判，2 已判。圖片 1、2 是本教材自行產生的 1×1 灰色 PNG（各 69 bytes）；3 刻意缺圖。
`clean.txt` 只含 1、2，適合成功案例；duplicate／malformed 是反例；empty 只有標頭。
格式是教材自訂的兩欄 ASCII 清單，不是產線 CSV 匯出格式。讀者不需客戶資料或 GPU。檢查器不解碼 PNG，檔案非空不代表模型讀得懂。
