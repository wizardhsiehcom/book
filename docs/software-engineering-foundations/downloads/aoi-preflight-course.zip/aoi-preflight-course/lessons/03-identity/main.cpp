#include <fstream>   // ifstream：擁有檔案資源；離開作用域時釋放。
#include <iostream>  // cout / cerr：正常報告與錯誤分流。
#include <stdexcept> // runtime_error：帶理由的失敗。
#include <string>    // string：擁有字串內容。
#include <vector>    // vector<Row>：筆數隨清單而變的連續容器。
#include <sstream>   // istringstream：將一行當輸入讀取。
#include <charconv>  // from_chars：轉數字，並檢查是否吃完整欄。
#include <filesystem>
#include <unordered_set>
namespace fs = std::filesystem;
// id 是本次清單內的身分；judge=-1 待判，0..99 是教材允許的已判值。
struct Row { int id; int judge; };
// s.c_str() 等不是數字；不要把只成功讀取前綴當成完整驗證。
int number(const std::string& text) {
    int value = 0;
    const auto parsed = std::from_chars(text.data(), text.data() + text.size(), value);
    if (parsed.ec != std::errc{} || parsed.ptr != text.data() + text.size())
        throw std::runtime_error("invalid integer: " + text);
    return value;
}
// in 是可變參照：讀取會改變串流位置。回傳 vector 由呼叫者擁有。
std::vector<Row> load(std::istream& in) {
    std::string line;
    if (!std::getline(in, line)) throw std::runtime_error("missing header");
    if (!line.empty() && line.back() == '\r') line.pop_back();
    if (line != "id judge") throw std::runtime_error("expected header: id judge");
    std::vector<Row> rows;
    std::unordered_set<int> seen;
    std::size_t line_number = 1;
    while (std::getline(in, line)) {
        ++line_number;
        std::istringstream fields(line);
        std::string id, judge, extra;
        if (!(fields >> id)) continue; // 空白行不是一筆工作。
        if (!(fields >> judge) || (fields >> extra))
            throw std::runtime_error("line " + std::to_string(line_number) + ": expected two fields");
        const Row row{number(id), number(judge)};
        if (row.id < 1 || row.id > 999999 || row.judge < -1 || row.judge > 99)
            throw std::runtime_error("line " + std::to_string(line_number) + ": value out of range");
        // insert 回傳 pair；second=false 代表此身分已經出現。
        if (!seen.insert(row.id).second) throw std::runtime_error("duplicate id: " + id);
        rows.push_back(row); // 值複製進容器；row 的作用域結束不會刪除這份值。
    }
    if (in.bad()) throw std::runtime_error("manifest read failed");
    return rows; // 回傳擁有資料的值，不回傳區域變數的參照。
}
// 只作開啟探測；G04 會區分空檔、目錄、symlink 與其他 I/O 錯誤。
bool available(const fs::path& path) {
    std::ifstream image(path, std::ios::binary);
    return static_cast<bool>(image);
}
// root 由使用者選定；檔名只由已驗證的正整數產生，不接受清單內任意路徑。
int report(const std::vector<Row>& rows, const fs::path& root ) {
    if (!fs::is_directory(root)) throw std::runtime_error("image root is not a directory");
    std::size_t pending = 0, ready = 0;
    for (const Row& row : rows) { // const&：只讀原列，不複製、不修改 judge。
        if (row.judge != -1) continue;
        ++pending;
        const fs::path path = root / (std::to_string(row.id) + ".png");
        const std::string state = (available(path) ? "ready" : "missing");
        if (state == "ready") ++ready;
        std::cout << "id=" << row.id << " state=" << state << '\n';
    }
    std::cout << "total=" << rows.size() << " pending=" << pending
              << " ready=" << ready << " issues=" << pending - ready << '\n';
    return pending == ready ? 0 : 1; // 1 是完成檢查但發現問題；2 才是無法完成檢查。
}
int main(int argc, char** argv) {
    try {
        if (argc != 3) throw std::runtime_error("usage: g03 MANIFEST IMAGE_ROOT ");
        
        std::ifstream input(argv[1]);
        if (!input) throw std::runtime_error("cannot open manifest");
        const auto rows = load(input);
        return report(rows, fs::path(argv[2]) );
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 2;
    }
}
