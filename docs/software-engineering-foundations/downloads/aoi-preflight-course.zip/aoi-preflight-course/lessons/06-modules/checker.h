#pragma once
#include <cstdint>
#include <filesystem>
#include <istream>
#include <string>
#include <vector>
struct Row { int id; int judge; };
int number(const std::string& text);
std::vector<Row> load(std::istream& in);
std::string inspect(const std::filesystem::path& path, std::uintmax_t minimum);
int report(const std::vector<Row>& rows, const std::filesystem::path& root, std::uintmax_t minimum);
