#include "checker.h"
#include <fstream>
#include <iostream>
#include <stdexcept>
namespace fs = std::filesystem;
int main(int argc, char** argv) {
    try {
        if (argc != 4) throw std::runtime_error("usage: g06 MANIFEST IMAGE_ROOT MIN_BYTES");
        const int minimum = number(argv[3]);
        if (minimum < 1 || minimum > 1000000) throw std::runtime_error("MIN_BYTES must be 1..1000000");
        std::ifstream input(argv[1]);
        if (!input) throw std::runtime_error("cannot open manifest");
        const auto rows = load(input);
        return report(rows, fs::path(argv[2]) , static_cast<std::uintmax_t>(minimum));
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 2;
    }
}
