// G01：先把注意力留給「一筆資料如何變成報告」。清單尚未外部化。
#include <filesystem> // path 的 / 負責組路徑，不必自己拼斜線。
#include <fstream>    // ifstream 建構時開啟，解構時關閉檔案。
#include <iostream>   // << 將值送到輸出串流。
#include <stdexcept>
#include <string>
namespace fs = std::filesystem;
struct Row { int id; int judge; }; // struct 將一筆資料的兩個欄位放在一起。
bool available(const fs::path& path) {
    std::ifstream image(path, std::ios::binary);
    return static_cast<bool>(image); // 開得了不等於圖片有效，G04 再加檔案規則。
}
int main(int argc, char** argv) { // argc 包含程式名稱；argv[1] 是第一個輸入。
    try {
        if (argc != 2) throw std::runtime_error("usage: g01 IMAGE_ROOT");
        const fs::path root(argv[1]);
        if (!fs::is_directory(root)) throw std::runtime_error("image root is not a directory");
        const Row rows[] = {{1, -1}, {2, 2}, {3, -1}};
        int pending = 0, ready = 0; // 必須初始化；計數從零開始。
        for (const Row& row : rows) { // & 借用原列；const 禁止透過 row 修改它。
            if (row.judge != -1) continue; // 本課只查待判列；已判的不納入。
            ++pending;
            const auto path = root / (std::to_string(row.id) + ".png");
            const bool found = available(path);
            if (found) ++ready;
            std::cout << "id=" << row.id << " state=" << (found ? "ready" : "missing") << '\n';
        }
        std::cout << "total=3 pending=" << pending << " ready=" << ready
                  << " issues=" << pending - ready << '\n';
        return pending == ready ? 0 : 1;
    } catch (const std::exception& error) {
        std::cerr << "ERROR: " << error.what() << '\n';
        return 2;
    }
}
