// ASCII-only diagnostic: it must compile even with the wrong source encoding.
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
void require(bool condition) {
    if (!condition) throw std::runtime_error("deliberate failure");
}
int main(int argc, char** argv) {
    bool ok = true;
#ifdef _MSVC_LANG
    const long language = _MSVC_LANG;
#else
    const long language = __cplusplus;
#endif
    std::cout << "language=" << language << " need>=201703\n";
    if (language < 201703L) { std::cerr << "Use C++17 compiler flags.\n"; ok = false; }
    bool caught = false;
    try { require(false); } catch (const std::runtime_error&) { caught = true; }
    if (!caught) ok = false;
    std::cout << "check-active=" << caught << " (independent of assert/NDEBUG)\n";
    std::ifstream in(argc > 1 ? argv[1] : "fixtures/defects.txt");
    std::string header;
    if (!std::getline(in, header) || (header != "id judge" && header != "id judge\r")) {
        std::cerr << "Fixture missing or wrong header. Run from repository root.\n"; ok = false;
    }
    std::cout << "environment=" << (ok ? "PASS" : "FAIL") << '\n';
    return ok ? 0 : 2;
}
