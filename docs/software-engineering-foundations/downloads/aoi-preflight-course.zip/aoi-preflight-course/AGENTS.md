# C00 教材維護

先讀 `plan/course-plan.md`。正文使用繁體中文。各階完整快照獨立，不把末階實作抽成所有階段共用核心。改動後執行 `python3 tools/course.py test`；Windows 使用 `py`。來源資料放 data，讀者輸入放 fixtures。不得將建置驗證當成讀者已學會。
