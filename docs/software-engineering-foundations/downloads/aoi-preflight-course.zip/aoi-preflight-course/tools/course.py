"""Build/run frozen lessons. Python 3.10+, C++17 compiler; no third-party packages."""
from pathlib import Path
import argparse
import os
import shutil
import subprocess
import sys
ROOT = Path(__file__).resolve().parents[1]
LESSONS = sorted((ROOT / "lessons").glob("[0-9][0-9]-*"))

def binary(stage):
    name = f"g{stage:02}" if isinstance(stage, int) else stage
    return ROOT / "build" / (name + (".exe" if os.name == "nt" else ""))

def build(stage, release=False):
    directory = ROOT / "solutions/capstone" if stage == "capstone" else LESSONS[stage]
    output = binary(stage)
    output.parent.mkdir(exist_ok=True)
    compiler = os.environ.get("CXX") or ("cl" if os.name == "nt" else "c++")
    if not shutil.which(compiler):
        raise RuntimeError(f"Compiler {compiler!r} missing. See README environment setup.")
    sources = [str(p) for p in sorted(directory.glob("*.cpp"))]
    if Path(compiler).stem.lower() == "cl":
        flags = ["/nologo", "/std:c++17", "/EHsc", "/utf-8", "/W4"]
        flags += ["/O2", "/DNDEBUG"] if release else ["/Od", "/Zi"]
        cmd = [compiler, *flags, *sources, "/Fe:" + str(output)]
    else:
        flags = ["-std=c++17", "-Wall", "-Wextra", "-Wpedantic"]
        flags += ["-O2", "-DNDEBUG"] if release else ["-O0", "-g"]
        cmd = [compiler, *flags, *sources, "-o", str(output)]
    # Build failure stops here; do not run a stale executable.
    print("BUILD", directory.name, flush=True)
    subprocess.run(cmd, cwd=output.parent, check=True, timeout=120)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["build", "run", "test"])
    parser.add_argument("stage", nargs="?", type=int, choices=range(len(LESSONS)))
    parser.add_argument("--release", action="store_true")
    args, rest = parser.parse_known_args()
    try:
        if args.action == "run":
            if args.stage is None:
                parser.error("run requires a stage")
            build(args.stage, args.release)
            if rest and rest[0] == "--": rest = rest[1:]
            raise SystemExit(subprocess.run([str(binary(args.stage)), *rest], cwd=ROOT, timeout=30).returncode)
        if rest:
            parser.error("extra arguments only allowed for run")
        for stage in ([args.stage] if args.stage is not None else range(len(LESSONS))):
            build(stage, args.release)
        if args.action == "test":
            if args.stage is not None:
                parser.error("test builds all stages; omit stage")
            build("capstone", args.release)
            subprocess.run([sys.executable, str(ROOT / "tools/check_docs.py")], cwd=ROOT, check=True, timeout=30)
            subprocess.run([sys.executable, str(ROOT / "tools/check.py")], cwd=ROOT, check=True, timeout=90)
    except (RuntimeError, OSError, subprocess.SubprocessError) as error:
        print(error, file=sys.stderr)
        raise SystemExit(2)
