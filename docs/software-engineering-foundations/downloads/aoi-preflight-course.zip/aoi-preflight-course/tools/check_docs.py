"""Check local Markdown links and executable lesson references."""
from pathlib import Path
import re
import shlex
from urllib.parse import unquote
ROOT = Path(__file__).resolve().parents[1]

def check_link(source, target):
    path = unquote(target.split('#', 1)[0])
    if not path or ':' in path or path.startswith('/'):
        return
    if not (source.parent / path).exists():
        raise RuntimeError(f'{source.relative_to(ROOT)}: missing {target}')

if __name__ == '__main__':
    # Demonstrate detection rather than just claim the checker works.
    caught = False
    try:
        check_link(ROOT / 'README.md', 'known-missing-document.md')
    except RuntimeError:
        caught = True
    if not caught:
        raise RuntimeError('document check did not reject a broken link')
    count = 0
    for source in ROOT.rglob('*.md'):
        if '.git' in source.parts or any(p.startswith('build') for p in source.parts):
            continue
        text = source.read_text(encoding='utf-8')
        for target in re.findall(r'\]\(([^\s)]+)\)', text):
            check_link(source, target)
            count += 1
        for command in re.findall(r'^python3 tools/course.py run .+$', text, re.M):
            fields = shlex.split(command)
            stage = int(fields[3])
            matches = list((ROOT / 'lessons').glob(f'{stage:02}-*/main.cpp'))
            if len(matches) != 1:
                raise RuntimeError(f'{source}: command has no unique stage: {command}')
            if '--' in fields:
                for argument in fields[fields.index('--')+1:]:
                    if argument.startswith('fixtures/') and not (ROOT / argument).exists():
                        raise RuntimeError(f'{source}: missing command input {argument}')
    print(f'PASS: {count} Markdown link references; lesson commands resolve')
