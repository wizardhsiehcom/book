"""Behavior checks: explicit exceptions, never disabled by Python -O or C++ NDEBUG."""
from pathlib import Path
import os
import subprocess
import tempfile
from course import ROOT, binary

checks = 0

def expect(condition, message):
    global checks
    if not condition:
        raise RuntimeError(message)
    checks += 1

def run(stage, args, code, fragments=()):
    result = subprocess.run([str(binary(stage)), *map(str, args)], cwd=ROOT,
                            capture_output=True, text=True, timeout=10)
    expect(result.returncode == code, f'stage {stage}: code {result.returncode}, expected {code}: {result.stderr}')
    for fragment in fragments:
        expect(fragment in result.stdout + result.stderr, f'stage {stage}: missing {fragment!r}: {result.stdout} {result.stderr}')
    return result.stdout

caught = False
try:
    expect(False, 'deliberate checker failure')
except RuntimeError:
    caught = True
expect(caught, 'check mechanism inactive')
run(0, [], 0, ['check-active=1', 'environment=PASS'])
run(0, ['not-a-fixture.txt'], 2, ['environment=FAIL'])
images = ROOT / 'fixtures/images'
run(1, [images], 1, ['id=1 state=ready', 'id=3 state=missing', 'pending=2 ready=1 issues=1'])
for stage in range(2, 7):
    def args(manifest, root=images, minimum='1'):
        return [manifest, root] + ([minimum] if stage >= 5 else [])
    run(stage, args(ROOT / 'fixtures/defects.txt'), 1, ['total=3 pending=2 ready=1 issues=1'])
    run(stage, args(ROOT / 'fixtures/clean.txt'), 0, ['total=2 pending=1 ready=1 issues=0'])
    run(stage, args(ROOT / 'fixtures/empty.txt'), 0, ['total=0 pending=0 ready=0 issues=0'])
    run(stage, args(ROOT / 'fixtures/duplicate.txt'), 2, ['duplicate id'])
    run(stage, args(ROOT / 'fixtures/malformed.txt'), 2, ['invalid integer'])
    run(stage, args('does-not-exist.txt'), 2, ['cannot open manifest'])
    run(stage, args(ROOT / 'fixtures/clean.txt', ROOT / 'fixtures/clean.txt'), 2, ['not a directory'])
    with tempfile.TemporaryDirectory() as temporary:
        tmp = Path(temporary)
        manifest = tmp / 'input.txt'
        for bad, reason in [('id judge\n1 -1 extra\n','two fields'), ('id judge\n0 -1\n','out of range'),
                            ('id judge\n1 -2\n','out of range'), ('id judge\n999999999999999999 -1\n','invalid integer'),
                            ('wrong\n','expected header'), ('','missing header')]:
            manifest.write_text(bad)
            run(stage, args(manifest), 2, [reason])
        manifest.write_bytes(b'id judge\r\n\r\n1 -1\r\n2 2\r\n')
        run(stage, args(manifest), 0, ['total=2 pending=1 ready=1 issues=0'])
        if stage >= 4:
            folder = tmp / 'images'; folder.mkdir()
            (folder / '1.png').write_bytes(b'')
            run(stage, args(manifest, folder), 1, ['id=1 state=too-small'])
            (folder / '1.png').unlink(); (folder / '1.png').mkdir()
            run(stage, args(manifest, folder), 1, ['id=1 state=not-regular'])
            (folder / '1.png').rmdir()
            if os.name != 'nt':
                (folder / '1.png').symlink_to(images / '1.png')
                run(stage, args(manifest, folder), 1, ['id=1 state=symlink'])
        if stage >= 5:
            for bad in ('0','-1','1000001','1x'):
                run(stage, args(manifest, minimum=bad), 2)
            run(stage, args(manifest, minimum='100'), 1, ['id=1 state=too-small'])
            size = str((images / '1.png').stat().st_size)
            run(stage, args(manifest, minimum=size), 0, ['ready=1 issues=0'])
# Refactor keeps exact report for the same input.
a = run(5, [ROOT/'fixtures/defects.txt', images, '1'], 1)
b = run(6, [ROOT/'fixtures/defects.txt', images, '1'], 1)
expect(a == b, 'G05 -> G06 report changed')
run('capstone', [ROOT/'fixtures/defects.txt', images, '1', 'pending', 'png'], 1, ['selected=2 ready=1 issues=1'])
run('capstone', [ROOT/'fixtures/defects.txt', images, '1', 'all', 'png'], 1, ['selected=3 ready=2 issues=1'])
run('capstone', [ROOT/'fixtures/defects.txt', images, '1', 'all', 'jpg'], 1, ['selected=3 ready=0 issues=3'])
run('capstone', [ROOT/'fixtures/defects.txt', images, '1', 'weird', 'png'], 2, ['scope must'])
run('capstone', [ROOT/'fixtures/defects.txt', images, '1', 'all', '../png'], 2, ['extension must'])
with tempfile.TemporaryDirectory() as temporary:
    folder = Path(temporary)
    (folder/'1.jpg').write_bytes(b'fake-image-for-path-test')
    run('capstone', [ROOT/'fixtures/clean.txt', folder, '1', 'pending', 'jpg'], 0, ['selected=1 ready=1 issues=0'])
print(f'PASS: {checks} behavioral checks; Windows symlink case skipped on Windows')
