# 工程驗證紀錄

日期：2026-09-26。平台：macOS／Darwin arm64，Apple Clang 21.0.0（clang-2100.1.1.101）。初次建置入口 Python 3.9.6；讀者建議使用 3.10+。正式落點另以 Python 3.12.12 重驗並保存 log。

| 檢查 | 結果與範圍 |
|---|---|
| G00–G06、capstone Debug | 199 項行為檢查通過；每個完整版本實際編譯與執行 |
| 同上 Release | -O2 -DNDEBUG，199 項通過；不是只看 assert 或 PASS 字串 |
| G00 以 C++11 編譯 | 可執行並回 2，顯示 language=201103 與 C++17 修法 |
| G00 不存在的 fixture | 回 2、environment=FAIL；修回路徑後 PASS |
| 文件核對 | 132 個 Markdown 連結引用與各階命令可定位；先以不存在連結證明檢查會拒絕 |
| G05→G06 | 同輸入報告逐字相等，並各自覆蓋正常與失敗案例 |
| capstone | pending／all、png／jpg、錯誤 scope、路徑式副檔名拒絕；合成 JPG 只測檔案路徑契約 |

命令：`python3 tools/course.py test` 與 `python3 tools/course.py test --release`。來源不需產線資料或已存在 build；測試的可變資料放暫存目錄，結束後清理。G01 正常輸入仍回 1，因為 fixture 刻意缺圖。

實際涵蓋：缺圖、空清單、CRLF、空白行、錯標頭、缺欄、多欄、壞數字／溢位、id／judge 範圍、重複 id、錯根目錄、空檔、目錄、macOS symlink、門檻輸入與等值邊界。負面文件檢查曾抓到尚未建立的 verification 頁，補齊後通過。

未驗：Windows／MSVC、Linux 實機、遠端 CI、影像解碼、Unicode 路徑、檔案系統競態、真機台格式及強制 I/O 故障。io-error 分支有實作，未以權限故障注入覆蓋所有作業系統分支。read-only 不表示此工具能抵禦惡意同步替換檔案；它是靜態目錄的離線檢查工具。

**學習驗收尚未執行。** 程式通過不代表讀者已通過免修診斷或 capstone。
