# G02｜外部清單：筆數改變不該重編譯

## 現在卡在哪裡

固定三列可以示範，但新批次有不同筆數。現在只將資料來源換成檔案，圖片探測與統計規則保持。

完整版本：[main.cpp](../lessons/02-load/main.cpp)。前版是 G01；先保留它供比較。

## 先猜，再操作

**先寫下答案與理由：清單含 `1oops -1`，把 1 前綴讀出來算成功嗎？第二列格式壞掉時，能不能先印第一列的成功摘要？** 不必一次猜對；把原先假設留著，執行後才知道是哪條邏輯需要修正。

在 課程目錄（`courses/aoi-preflight-course/`）：

```sh
python3 tools/course.py run 2 -- fixtures/defects.txt fixtures/images
```

命令會建置本階再執行；不需啟動服務。正常短案例數秒內完成，工具對執行設 30 秒上限。可用 Ctrl+C 停止。只讀操作能直接重跑；若改 fixture，先保留原份。

## 現象如何發生

`load` 先讀標頭，再逐行拆出恰好兩欄。from_chars 的錯誤碼與結束位置都通過才收下整數。id 與 judge 有界；重複 id 直接拒絕。整份清單通過後才呼叫 report，因此格式錯誤不會伴隨一份看似完整的成功摘要。

## 只改這一步

相較 G01，固定陣列被 `vector<Row>` 取代。每列 push_back 一個值，擁有權留在 vector；不將 line 或區域 row 的參照留到下一輪。ifstream 的擁有者是 main，解析函式只借用讀取。這就是輸入契約與資源歸屬的第一個分界。

第一次出現的語法在原碼註解；遇到已出現的 vector、const&、ifstream，回 G01／G02 查，不把整份註解再背一次。第 6 階另讀 [checker.h](../lessons/06-modules/checker.h) 與 [checker.cpp](../lessons/06-modules/checker.cpp)。

## 換個條件

使用 duplicate、malformed、empty 三份 fixtures。先預測哪個回 0、哪個回 2，並解釋空清單為何不是格式錯誤。

先做[本階練習](../exercises/02-load.md)，需要時只開[提示](../solutions/02-load-hints.md)，最後才看[解答與判準](../solutions/02-load.md)。驗收要交出預測、修改差異和實際結果，不只說「跑通」。

## 本版界線與下一步

目前每筆查重都掃前面全部資料。下一階讓筆數變大後的成本可以被分析。

資料格式與演進順序是本教材設計；不是原機台歷史。[來源與證據](../data/README.md)；[實際工程驗證](../verification/results.md)。
