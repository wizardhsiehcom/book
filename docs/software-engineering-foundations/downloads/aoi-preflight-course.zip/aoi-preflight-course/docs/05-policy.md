# G05｜規則變了：把門檻放在可檢查的入口

## 現在卡在哪裡

檢查非空只能排除空檔。如果一批資料另有最小大小要求，硬把判斷散落各處，之後容易改漏。

完整版本：[main.cpp](../lessons/05-policy/main.cpp)。前版是 G04；先保留它供比較。

## 先猜，再操作

**先寫下答案與理由：圖片剛好等於 MIN_BYTES，要過還是失敗？輸入 -1 若先轉成無號數會發生什麼？** 不必一次猜對；把原先假設留著，執行後才知道是哪條邏輯需要修正。

在 課程目錄（`courses/aoi-preflight-course/`）：

```sh
python3 tools/course.py run 5 -- fixtures/defects.txt fixtures/images 1
```

命令會建置本階再執行；不需啟動服務。正常短案例數秒內完成，工具對執行設 30 秒上限。可用 Ctrl+C 停止。只讀操作能直接重跑；若改 fixture，先保留原份。

## 現象如何發生

main 先解析帶符號的整數，確定 1..1000000 後才轉成 uintmax_t。report 接受 minimum，再原樣傳給 inspect。核心規則只在一處：bytes < minimum 才是 too-small。

## 只改這一步

這次參數存在，是因為操作者真的要切換門檻，而不是預留未來擴充。預設讀法仍用 1，可對照 G04；改成 100 時，教材小 PNG 也會不通過。大小門檻不等於影像品質驗證，不能拿它代替解碼。

第一次出現的語法在原碼註解；遇到已出現的 vector、const&、ifstream，回 G01／G02 查，不把整份註解再背一次。第 6 階另讀 [checker.h](../lessons/06-modules/checker.h) 與 [checker.cpp](../lessons/06-modules/checker.cpp)。

## 換個條件

用檔案實際大小作為門檻，再加 1。兩次結果應恰好跨越邊界；加入一個 0 或超大值，應該是輸入錯誤而非缺圖。

先做[本階練習](../exercises/05-policy.md)，需要時只開[提示](../solutions/05-policy-hints.md)，最後才看[解答與判準](../solutions/05-policy.md)。驗收要交出預測、修改差異和實際結果，不只說「跑通」。

## 本版界線與下一步

規則已經有自己的輸入與結果。下一階把入口和核心分開，利用相同行為檢查避免重構改語意。

資料格式與演進順序是本教材設計；不是原機台歷史。[來源與證據](../data/README.md)；[實際工程驗證](../verification/results.md)。
