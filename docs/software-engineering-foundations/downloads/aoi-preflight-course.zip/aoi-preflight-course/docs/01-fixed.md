# G01｜固定三列：先產出待判與缺圖報告

## 現在卡在哪裡

接手一批影像時，最先想知道的是哪些待判列沒有檔案。先固定三筆，不同時學清單格式與解析。

完整版本：[main.cpp](../lessons/01-fixed/main.cpp)。前版是 G00；先保留它供比較。

## 先猜，再操作

**先寫下答案與理由：id=2 有圖片但已判，它要算進 ready 嗎？id=3 缺圖，結束碼要是 1 還是 2？** 不必一次猜對；把原先假設留著，執行後才知道是哪條邏輯需要修正。

在 課程目錄（`courses/aoi-preflight-course/`）：

```sh
python3 tools/course.py run 1 -- fixtures/images
```

命令會建置本階再執行；不需啟動服務。正常短案例數秒內完成，工具對執行設 30 秒上限。可用 Ctrl+C 停止。只讀操作能直接重跑；若改 fixture，先保留原份。

## 現象如何發生

`rows` 陣列擁有三筆 Row。for 每輪將 row 借用到其中一筆，const 禁止從這個入口改值。判斷 judge 後才查圖，因此總列數、待判數與 ready 是三種不同統計。

## 只改這一步

`available` 裡的 ifstream 在呼叫結束時關檔，外面只取得 bool。第一版只提供開啟探測；對受控 fixture 有用，但還不能辨識空檔或目錄，G04 會補。程式沒有把圖片內容存入記憶體，也沒有宣稱有效像素。

第一次出現的語法在原碼註解；遇到已出現的 vector、const&、ifstream，回 G01／G02 查，不把整份註解再背一次。第 6 階另讀 [checker.h](../lessons/06-modules/checker.h) 與 [checker.cpp](../lessons/06-modules/checker.cpp)。

## 換個條件

在自己的練習副本把 id=2 的 judge 改成 -1；先算答案，再重建。用 debugger 在 `if (row.judge != -1)` 停住看每一列。

先做[本階練習](../exercises/01-fixed.md)，需要時只開[提示](../solutions/01-fixed-hints.md)，最後才看[解答與判準](../solutions/01-fixed.md)。驗收要交出預測、修改差異和實際結果，不只說「跑通」。

## 本版界線與下一步

每批都要改原碼很麻煩；下一階讓清單來自檔案。

資料格式與演進順序是本教材設計；不是原機台歷史。[來源與證據](../data/README.md)；[實際工程驗證](../verification/results.md)。
