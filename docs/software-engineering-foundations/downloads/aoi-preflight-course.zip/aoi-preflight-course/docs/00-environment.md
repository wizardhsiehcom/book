# G00｜環境：檢查器自己可信嗎？

## 現在卡在哪裡

沒有能執行的程式，討論缺圖只是在紙上推理。更麻煩的是檢查機制可能被建置旗標取消：顯示 PASS 不一定真的驗過。

完整版本：[main.cpp](../lessons/00-environment/main.cpp)。先依根 README 安裝環境。

## 先猜，再操作

**先寫下答案與理由：若把編譯改成 Release，檢查還會執行嗎？若從錯誤目錄啟動，程式應該回報什麼？** 不必一次猜對；把原先假設留著，執行後才知道是哪條邏輯需要修正。

在 課程目錄（`courses/aoi-preflight-course/`）：

```sh
python3 tools/course.py run 0
```

命令會建置本階再執行；不需啟動服務。正常短案例數秒內完成，工具對執行設 30 秒上限。可用 Ctrl+C 停止。只讀操作能直接重跑；若改 fixture，先保留原份。

## 現象如何發生

環境程式使用 C++11 可表達的功能，透過語言版本值判定是否達 C++17；本身不使用 filesystem，所以錯誤語言模式下仍可說明原因。ASCII 原碼也避免依賴正在檢查的中文編碼。

## 只改這一步

`require(false)` 故意拋出例外，呼叫端必須真的捕捉到，才算檢查有效。它不依賴 NDEBUG。這個機制只驗本檢查的作用，不能拿來保證任意測試框架都有效。

第一次出現的語法在原碼註解；遇到已出現的 vector、const&、ifstream，回 G01／G02 查，不把整份註解再背一次。第 6 階另讀 [checker.h](../lessons/06-modules/checker.h) 與 [checker.cpp](../lessons/06-modules/checker.cpp)。

## 換個條件

改用不存在的 fixture 參數；觀察 FAIL、修回後再觀察 PASS。

先做[本階練習](../exercises/00-environment.md)，需要時只開[提示](../solutions/00-environment-hints.md)，最後才看[解答與判準](../solutions/00-environment.md)。驗收要交出預測、修改差異和實際結果，不只說「跑通」。

## 本版界線與下一步

第一次編譯成功只是起點。接著用固定三列做出有用報告。

資料格式與演進順序是本教材設計；不是原機台歷史。[來源與證據](../data/README.md)；[實際工程驗證](../verification/results.md)。
