# G03｜查重：保留身分規則，換掉搜尋成本

## 現在卡在哪裡

G02 已經正確拒絕重複身分。現在不是修錯，而是發現每筆都掃前面，清單長大時比較次數增加太快。

完整版本：[main.cpp](../lessons/03-identity/main.cpp)。前版是 G02；先保留它供比較。

## 先猜，再操作

**先寫下答案與理由：n 筆不重複資料，逐筆掃描總共比幾次？改成 unordered_set 後，輸出列的順序會變嗎？** 不必一次猜對；把原先假設留著，執行後才知道是哪條邏輯需要修正。

在 課程目錄（`courses/aoi-preflight-course/`）：

```sh
python3 tools/course.py run 3 -- fixtures/defects.txt fixtures/images
```

命令會建置本階再執行；不需啟動服務。正常短案例數秒內完成，工具對執行設 30 秒上限。可用 Ctrl+C 停止。只讀操作能直接重跑；若改 fixture，先保留原份。

## 現象如何發生

G02 最壞比較次數是 n(n-1)/2。G03 只把已看過的 id 放進 unordered_set；insert 的 second 表示是否首次插入，失敗就拒絕。rows 仍保留原始順序，沒有改成迭代 set 產生報告。

## 只改這一步

差異集中在 `load` 的 seen 宣告與查重區塊。平均查找／插入可視為常數，最壞仍可能線性；整批期望線性不是任何輸入都保證線性。這也不是磁碟速度 benchmark。要驗證改善，先核對查重語意沒有改变，再量測實際瓶颈。

第一次出現的語法在原碼註解；遇到已出現的 vector、const&、ifstream，回 G01／G02 查，不把整份註解再背一次。第 6 階另讀 [checker.h](../lessons/06-modules/checker.h) 與 [checker.cpp](../lessons/06-modules/checker.cpp)。

## 換個條件

將兩筆相同 id 的 judge 設成不同值。是否還要拒絕？觀察「身分」不能用完整 Row 當替代。

先做[本階練習](../exercises/03-identity.md)，需要時只開[提示](../solutions/03-identity-hints.md)，最後才看[解答與判準](../solutions/03-identity.md)。驗收要交出預測、修改差異和實際結果，不只說「跑通」。

## 本版界線與下一步

查重成本改善了，但一個空的圖片檔仍可能被視為可用；下一階把檔案契約說清楚。

資料格式與演進順序是本教材設計；不是原機台歷史。[來源與證據](../data/README.md)；[實際工程驗證](../verification/results.md)。
