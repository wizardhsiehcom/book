# G06｜拆模組：讓修改有可以核對的邊界

## 現在卡在哪裡

工具已經有 load、inspect、report；把全部留在 main.cpp 也能用。但現在要獨立閱讀解析與檔案規則，入口細節開始妨礙修改。

完整版本：[main.cpp](../lessons/06-modules/main.cpp)。前版是 G05；先保留它供比較。

## 先猜，再操作

**先寫下答案與理由：只移到 checker.cpp 和 checker.h，報告有任何理由改變嗎？只編譯 main.cpp 為什麼會有未解析符號？** 不必一次猜對；把原先假設留著，執行後才知道是哪條邏輯需要修正。

在 課程目錄（`courses/aoi-preflight-course/`）：

```sh
python3 tools/course.py run 6 -- fixtures/defects.txt fixtures/images 1
```

命令會建置本階再執行；不需啟動服務。正常短案例數秒內完成，工具對執行設 30 秒上限。可用 Ctrl+C 停止。只讀操作能直接重跑；若改 fixture，先保留原份。

## 現象如何發生

checker.h 是宣告與共享的 Row，checker.cpp 定義解析和檢查，main.cpp 負責參數、檔案開啟與例外轉成結束碼。這是兩個翻譯單元；建置必須把兩個 cpp 一起送入連結。

## 只改這一步

沒有新增工廠、繼承或一堆介面。資料仍由 vector 擁有；main 借用核心的函式，核心不讀命令列。tools/check.py 對 G05／G06 的報告逐字比較，也檢查各種失敗契約，證明拆分至少保留已覆蓋的行為。

第一次出現的語法在原碼註解；遇到已出現的 vector、const&、ifstream，回 G01／G02 查，不把整份註解再背一次。第 6 階另讀 [checker.h](../lessons/06-modules/checker.h) 與 [checker.cpp](../lessons/06-modules/checker.cpp)。

## 換個條件

進入 capstone：新增 all／pending 範圍與 png／jpg 副檔名，不得修改輸入檔或默默接受未知值。先寫契約、判斷修改位置，再開始寫。

先做[本階練習](../exercises/06-modules.md)，需要時只開[提示](../solutions/06-modules-hints.md)，最後才看[解答與判準](../solutions/06-modules.md)。驗收要交出預測、修改差異和實際結果，不只說「跑通」。

## 本版界線與下一步

完成後可讀 Siguard 的真實命名、CSV 與判定鏈。此處不能直接搬去產線；需要核對真實欄位、失敗策略與檔案使用時機。

資料格式與演進順序是本教材設計；不是原機台歷史。[來源與證據](../data/README.md)；[實際工程驗證](../verification/results.md)。
