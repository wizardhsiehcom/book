# G04｜開得了不等於可以交付：檔案狀態

## 現在卡在哪裡

前一版只測能否開啟。現場補傳可能留下零 bytes；目錄、symlink 與 I/O 錯誤也不該通通寫成缺圖。

完整版本：[main.cpp](../lessons/04-files/main.cpp)。前版是 G03；先保留它供比較。

## 先猜，再操作

**先寫下答案與理由：0 bytes 的 3.png 存在，應算 ready 嗎？一個指向其他地方的 symlink，該按什麼政策處理？** 不必一次猜對；把原先假設留著，執行後才知道是哪條邏輯需要修正。

在 課程目錄（`courses/aoi-preflight-course/`）：

```sh
python3 tools/course.py run 4 -- fixtures/defects.txt fixtures/images
```

命令會建置本階再執行；不需啟動服務。正常短案例數秒內完成，工具對執行設 30 秒上限。可用 Ctrl+C 停止。只讀操作能直接重跑；若改 fixture，先保留原份。

## 現象如何發生

`inspect` 依序查 symlink_status、regular file、file_size 與可讀性。狀態分為 missing、symlink、not-regular、too-small、io-error、ready。先檢查 error_code，再使用數值，避免將失敗回傳當成很大的檔案。

## 只改這一步

替換點是報告迴圈中的 available 呼叫，改為 inspect(path, 1)。核心條件維持只查待判列；新增的是「檔案何時才算 ready」。拒絕 symlink 是本工具政策，不是 C++ 規定。輸入根目錄由操作者指定，清單只提供範圍內 id，無任意相對路徑。

第一次出現的語法在原碼註解；遇到已出現的 vector、const&、ifstream，回 G01／G02 查，不把整份註解再背一次。第 6 階另讀 [checker.h](../lessons/06-modules/checker.h) 與 [checker.cpp](../lessons/06-modules/checker.cpp)。

## 換個條件

在練習副本對 3.png 分別放空檔與目錄，確認狀態不同。所有操作都在可丟棄資料夾；不要改唯一一份真實圖片。

先做[本階練習](../exercises/04-files.md)，需要時只開[提示](../solutions/04-files-hints.md)，最後才看[解答與判準](../solutions/04-files.md)。驗收要交出預測、修改差異和實際結果，不只說「跑通」。

## 本版界線與下一步

這是靜態離線檢查，存在檢查與後續使用之間仍可能變化。不解碼、不防同步攻擊；需要線上可靠交付時接 C03。下一階讓最低檔案大小成為明確規則。

資料格式與演進順序是本教材設計；不是原機台歷史。[來源與證據](../data/README.md)；[實際工程驗證](../verification/results.md)。
