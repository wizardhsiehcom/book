# C00 來源與用途索引

取得／整理日期：2026-09-26。原始私人資料不複製到本 repo；這裡保留必要定位與抽象用途。此版不聲稱接過正式機台或真正使用者驗收。

| ID | 來源／版本 | 本次已讀範圍 | 用途與邊界 |
|---|---|---|---|
| U01 | 使用者本輪需求與 Obsidian 缺口建置計畫 | B01／C00 卡、實用面向與備料規則 | 明確授權製作書課；實用候選為離線清單檢查 |
| R01 | 相鄰 siguard-course，commit a8d3421718ff177f28be94a8001ed91a98ed064a | README、lessons/01-defect-identity/src/main.cpp、02-locate-image/src/main.cpp 完整；部分非同步正文 | 已有教學流程含待判篩選與圖片定位；不代表本工具格式與真機台相容 |
| R02 | 同 repo docs/misses.jsonl | 四筆完整紀錄 | Windows 編碼、CMake 語言、assert 與觀測界線的既有經驗；本版無第三方 C 原碼、不要求 CMake，不能假稱重現原事故 |
| T01 | ../Private/course-authoring/plan_template（Obsidian vault 內） | course-plan.template.md、chapter-template.md、README 完整 | 階段卡、預測、變式、證據與提示遞減 |
| W01 | [C++ Core Guidelines](https://isocpp.github.io/CppCoreGuidelines/CppCoreGuidelines) | 介面／參數與 RAII／錯誤處理相關節，非全本 | 原理建議，不是語言規格；以本課新例子說明 |
| W02 | [vector.capacity](https://eel.is/c++draft/vector.capacity) | 頁面本文 | 容量與參照失效；這是持續更新的標準草案，本例限制 C++17 子集 |
| W03 | [from_chars](https://eel.is/c++draft/charconv.from.chars) | 頁面本文 | 數值與消耗位置的驗證 |
| W04 | [filesystem regular file](https://eel.is/c++draft/fs.op.is.regular.file) | 頁面本文 | 檔案類型與錯誤碼 |
| W05 | [basic.life](https://eel.is/c++draft/basic.life) | 生命週期起迄與失效使用相關段落 | 借用不等於擁有；未依賴新草案特有語法 |
| W06 | [unordered requirements](https://eel.is/c++draft/unord.req) | 容器操作與複雜度相關節，非全頁 | 平均與最壞成本界線 |
| W07 | [Clang manual](https://clang.llvm.org/docs/UsersManual.html) | 標準、最佳化、除錯選項相關節，非全本 | 本機 compiler 旗標；實際版本在 verification |
| W08 | [MSVC command line](https://learn.microsoft.com/en-us/cpp/build/walkthrough-compiling-a-native-cpp-program-on-the-command-line?view=msvc-170) | 安裝／Developer Command Prompt／編譯步驟 | Windows 操作說明；本版未實機驗證 |
| W09 | [Python subprocess](https://docs.python.org/3/library/subprocess.html) | run、check、timeout 與引數相關節，非全頁 | 建置入口避免 shell 拼接 |
| W10 | [Git changes](https://git-scm.com/book/en/v2/Git-Basics-Recording-Changes-to-the-Repository)、[restore](https://git-scm.com/docs/git-restore) | working tree／index／差異與 restore 語意 | 學習差異與撤回 |
| W11 | [GitHub Actions quickstart](https://docs.github.com/en/actions/writing-workflows/quickstart) | workflow 入口與執行概念 | 最小 CI 設定；遠端未跑過 |

Web 資料只保留定位與整理筆記，不把整本文件下載重製。重要結论在程式實驗再驗；無法實測的能力明示。
