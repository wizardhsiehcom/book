# C00｜AOI 清單與圖片檢查器

給一份缺陷清單與圖片目錄，在開始判圖前找到待判列、缺圖、重複身分與過小檔案。這是一門 C++ 基礎銜接課：每版先解決一件有用的事，再因新輸入或需求暴露限制而修改。

**終點是離線檢查工具，不是模型推論，也不是原機台匯出格式的直接替代品。** 所有資料是合成的。工具只讀清單與圖片，報告寫到 stdout；不修改判定值、不寫庫、不刪圖片。

## 先修與免修診斷

你能辨認變數、if、for 與函式即可開始。不熟 `const&`、容器或檔案資源沒關係，第一次出現會在原碼解釋。先做[診斷](exercises/diagnostic.md)，通過者可跳到[末階遷移](exercises/capstone.md)，不必把已會的語法重讀一遍。

## 安裝與第一次成功

需要 C++17 編譯器、Python 3.10+（只負責建置與檢查）、Git。沒有額外 C++ 函式庫，不必先裝 CMake。

- **macOS（本版實測平台）**：執行 `xcode-select --install` 安裝 Command Line Tools；用 `c++ --version` 確認。Python 可使用現有 3.10+，以 `python3 --version` 核對；未安裝時到 Python 官方下載安裝。Git 可用 Command Line Tools 提供的版本。
- **Windows（操作路徑未實機驗證）**：Visual Studio Installer 勾選「使用 C++ 的桌面開發」，安裝 MSVC 與 Windows SDK；開 **x64 Native Tools Command Prompt for VS 2022**，以 `cl` 確認。安裝 Python 3.10+ 與 Git；下面的 `python3` 改用 `py`。所有建置均由同一支工具傳 `/std:c++17 /EHsc /utf-8`，不要另外省略旗標手動編譯。
- Linux 有近期 GCC／Clang 時可使用同一入口，但本版沒有實機驗證 Linux。不要把可編譯設計當成驗證紀錄。

先進入本課程目錄（`courses/aoi-preflight-course/`）。執行：

```sh
python3 tools/course.py run 0
python3 tools/course.py run 1 -- fixtures/images
```

G00 應印 `environment=PASS`。G01 的固定資料有兩列待判，1 有圖、3 缺圖，最後是 `total=3 pending=2 ready=1 issues=1`。因此這次 **exit code 是 1**，不是環境失敗。

| 結束碼 | 含義 | 該做什麼 |
|---|---|---|
| 0 | 檢查完成，待檢查圖片都符合本階規則 | 仍不代表圖片可被模型解碼 |
| 1 | 檢查完成，找到檔案問題 | 按 `id` 與 `state` 查資料 |
| 2 | 輸入／環境／操作錯誤，無法完成可信檢查 | 修正 `ERROR` 指出的條件再跑 |

讀 PowerShell 結束碼用 `$LASTEXITCODE`，POSIX shell 用 `echo $?`，必須緊接剛執行的命令。`course.py run` 會先建置再執行，不讓建置失敗後默默跑舊產物。

完整驗證：

```sh
python3 tools/course.py test
python3 tools/course.py test --release
```

檢查機制不依賴 `assert`，Release 的 `NDEBUG` 不會取消驗收。平常學習用預設 Debug（`-O0 -g`），方便逐行看變數。

## 常見卡關

| 症狀 | 原因與下一步 |
|---|---|
| 找不到 compiler | macOS 核對 Command Line Tools；Windows 改從 VS 的 Native Tools 終端開啟；自訂 compiler 可設定 CXX 為單一執行檔路徑 |
| 找不到 Python | 核對安裝與 PATH；Windows 試 `py --version` |
| G00 fixture FAIL | 回 課程目錄（`courses/aoi-preflight-course/`），不是在 lessons 裡執行；核對 fixtures/defects.txt |
| 找不到 filesystem／from_chars | 檢查實際 compiler 與 C++17 旗標；不拿更換副檔名當修法 |
| 報告說 image root 錯 | 第 1 階只收圖片目錄；第 2–4 階先收清單再收圖片目錄；第 5–6 階還需要 MIN_BYTES |
| 程式已完成但終端顯示非零 | 核對 1 與 2 的差別，不把找到缺圖當編譯失敗 |

CLI 輸出與 fixtures 採 ASCII，避免將 console 解碼混進第一個語法練習；正文與註解是 UTF-8。這不等於已測過所有 Unicode 路徑。

## 閱讀路線

先讀正文的問題與預測，寫下答案，再執行命令。接著讀本階原碼註解、做變式；最後才開解答。每個 `lessons/` 是完整版本，G06 不會改動 G01 的行為。

| 階段 | 正文 | 完整程式 | 這次新增的能力 |
|---|---|---|---|
| G00 | [環境](docs/00-environment.md) | [main.cpp](lessons/00-environment/main.cpp) | 確認環境與檢查有效 |
| G01 | [固定三列](docs/01-fixed.md) | [main.cpp](lessons/01-fixed/main.cpp) | 第一份待判／缺圖報告 |
| G02 | [讀外部清單](docs/02-load.md) | [main.cpp](lessons/02-load/main.cpp) | 變動筆數、嚴格解析 |
| G03 | [身分查找](docs/03-identity.md) | [main.cpp](lessons/03-identity/main.cpp) | 保留語意、改善查重成本 |
| G04 | [檔案狀態](docs/04-files.md) | [main.cpp](lessons/04-files/main.cpp) | 分辨空檔、目錄與連結 |
| G05 | [規則變動](docs/05-policy.md) | [main.cpp](lessons/05-policy/main.cpp) | 可驗證的最小檔案門檻 |
| G06 | [拆分與遷移](docs/06-modules.md) | [main.cpp](lessons/06-modules/main.cpp) | 凍結契約後分離核心與入口 |

每階原碼的差异用 `git diff --no-index lessons/02-load/main.cpp lessons/03-identity/main.cpp` 查看；有差異時 git 結束碼 1 是正常的。完整來源、教材計畫與驗證在 [data](data/README.md)、[plan](plan/course-plan.md)、[verification](verification/results.md)。

## 與 B01／Siguard 的關係

B01《從讀懂程式到能修改系統》在與 `courses` 同層的 `book` repo：`docs/software-engineering-foundations/README.md`。本課教工具如何一步步長出來，B01 負責原理與選擇的邊界。[概念對照](plan/coverage.md)列出章節檔名，網站未發布前不使用假 URL。

完成本課後接 Siguard：比較真正的身分欄位、圖片命名、CSV 解析與判定鏈。不要把本課 `id judge` 或 `<id>.png` 當成產線格式。
