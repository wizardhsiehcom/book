# 遷移：訓練資料入庫前的圖片檢查

另一份資料不是待判清單，而是已標記的訓練候選集。有些圖片是 JPG，已判過的列也需要檢查。

從 G06 建立自己的練習副本，新增兩個明確參數：`SCOPE` 只能是 pending 或 all；`EXT` 只能是 png 或 jpg。保留 MIN_BYTES、嚴格清單解析與檔案狀態。all 代表每列都檢查，pending 維持舊行為。報告把 pending 改為 selected，避免 all 時誤導。

驗收：

- pending/png/1 與舊版選到相同列；只允許欄名 pending 改 selected。
- all/png/1 選到三列，兩張存在、一張缺失。
- 用合成 jpg 測试（不需真解碼）證明副檔名參數有影響；標明只測路徑與檔案規則。
- 未知 scope 或 extension 回 2；不可接受任意路徑字串充當副檔名。
- 缺圖與格式錯誤維持不同結束碼，輸入檔不得修改。

先交契約與改動位置，再寫程式。提示：`report` 的選取判斷、檔名與統計名稱都會受影響；解析器不應因為 all 而放寬身分規則。

參考解在 [solutions/capstone](../solutions/capstone/README.md)，先不要開。完成一週後用另一份清單與門檻回測；能完成這種遷移才代表開始掌握。
